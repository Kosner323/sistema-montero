# -*- coding: utf-8 -*-
r"""
Sistema de Gestión Montero - Aplicación Principal
Versión: 1.2 - Integración de Pydantic y Swagger (flask-restx)
Fecha: 1 de noviembre de 2025
"""

# --- INICIO DE CORRECCIÓN DE IMPORTACIÓN ---
import os
import sys

# Añadir el directorio 'dashboard' (donde está app.py) al path
# para que las importaciones (ej. routes -> models) funcionen.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
# --- FIN DE CORRECCIÓN DE IMPORTACIÓN ---

from flask import (
    Flask,
    request,
    jsonify,
    send_file,
    send_from_directory,
    session,
    redirect,
)
from flask_cors import CORS
import sqlite3
from datetime import datetime
import io
import traceback
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from flask_restx import Api

# ==================== CARGAR VARIABLES DE ENTORNO ====================
load_dotenv()

# ==================== IMPORTAR UTILIDADES Y BLUEPRINTS ====================
from utils import get_db_connection, login_required

# Importamos el 'Namespace' (auth_ns) que creaste en routes/auth.py
from routes.auth import auth_ns

from routes.empresas import bp_empresas
from routes.usuarios import bp_usuarios
from routes.pagos import bp_pagos
from routes.formularios import bp_formularios
from routes.incapacidades import bp_incapacidades
from routes.tutelas import bp_tutelas
from routes.depuraciones import bp_depuraciones
from routes.cotizaciones import bp_cotizaciones
from routes.pago_impuestos import bp_impuestos
from routes.envio_planillas import bp_envio_planillas
from routes.credenciales import bp_credenciales
from routes.novedades import bp_novedades
from logger import get_logger

logger = get_logger(__name__)

# ==================== CONFIGURACIÓN DE RUTAS ====================
# (BASE_DIR ya está definido arriba)

# 🎨 ASSETS_DIR: Carpeta de archivos estáticos (CSS, JS, imágenes, etc.)
ASSETS_DIR = os.path.normpath(os.path.join(BASE_DIR, "..", "assets"))

# Otras carpetas
UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "formularios_pdf")
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.getenv("DATABASE_PATH", os.path.join(DATA_DIR, "mi_sistema.db"))

# Crear carpetas si no existen
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ==================== VERIFICACIÓN DE ASSETS_DIR ====================
logger.info("=" * 70)
logger.info("🚀 INICIANDO SISTEMA DE GESTIÓN MONTERO")
logger.info("=" * 70)
logger.info(f"📁 BASE_DIR: {BASE_DIR}")
logger.info(f"🎨 ASSETS_DIR: {ASSETS_DIR}")

if not os.path.isdir(ASSETS_DIR):
    logger.warning(f"⚠️  ADVERTENCIA: Carpeta 'assets' NO encontrada en: {ASSETS_DIR}")
    potential_assets_dir_sibling = os.path.join(BASE_DIR, "assets")
    if os.path.isdir(potential_assets_dir_sibling):
        ASSETS_DIR = potential_assets_dir_sibling
        logger.info(f"✅ Usando carpeta 'assets' encontrada en: {ASSETS_DIR}")
    else:
        logger.error(
            "❌ ERROR: No se encontró la carpeta 'assets' en ninguna ubicación"
        )
else:
    logger.info(f"✅ Carpeta 'assets' encontrada correctamente")

logger.info(f"📤 UPLOAD_FOLDER: {UPLOAD_FOLDER}")
logger.info(f"💾 DATABASE: {DB_PATH}")
logger.info("=" * 70)

# ==================== INICIALIZACIÓN DE FLASK ====================

# --- INICIO DE CORRECCIÓN (Error 404 en /docs/) ---
# Restaurar el static_folder. Flask-RESTX lo necesita para servir la UI de Swagger.
app = Flask(__name__, static_folder="static")
# --- FIN DE CORRECCIÓN ---


# Inicializar la API de flask-restx (Swagger)
api = Api(
    app,
    version="1.0",
    title="API Sistema Montero",
    description="Documentación interactiva de la API del Sistema Montero.",
    doc="/docs/",  # La documentación estará en http://127.0.0.1:5000/docs/
)

# ==================== CONFIGURACIÓN CORS ====================
cors_origins = os.getenv("CORS_ORIGINS", "http://127.0.0.1:5000,http://localhost:5000")
cors_origins_list = [origin.strip() for origin in cors_origins.split(",")]

CORS(
    app,
    resources={
        r"/api/*": {
            "origins": cors_origins_list,
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": [
                "Content-Type",
                "Accept",
                "Authorization",
                "X-Requested-With",
            ],
            "supports_credentials": True,
            "expose_headers": ["Content-Type"],
            "max_age": 3600,
        }
    },
    supports_credentials=True,
)

# ==================== CONFIGURACIÓN DE LA APLICACIÓN ====================
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise ValueError(
        "❌ ERROR CRÍTICO: SECRET_KEY no definida en variables de entorno (.env)"
    )

app.config["SECRET_KEY"] = SECRET_KEY
app.config["SESSION_COOKIE_HTTPONLY"] = (
    os.getenv("SESSION_COOKIE_HTTPONLY", "True").lower() == "true"
)
app.config["SESSION_COOKIE_SAMESITE"] = os.getenv("SESSION_COOKIE_SAMESITE", "Lax")
app.config["SESSION_COOKIE_SECURE"] = (
    os.getenv("SESSION_COOKIE_SECURE", "False").lower() == "true"
)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = int(
    os.getenv("MAX_CONTENT_LENGTH", 10 * 1024 * 1024)
)
app.config["ENV"] = os.getenv("FLASK_ENV", "production")
app.config["DEBUG"] = os.getenv("FLASK_DEBUG", "False").lower() == "true"


# ==================== INICIALIZACIÓN BASE DE DATOS ====================
def initialize_database():
    """Inicializa y configura la base de datos SQLite"""
    conn = get_db_connection()
    c = conn.cursor()

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS novedades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client TEXT,
            subject TEXT,
            priority TEXT,
            status TEXT,
            priorityText TEXT,
            idType TEXT,
            idNumber TEXT,
            firstName TEXT,
            lastName TEXT,
            nationality TEXT,
            gender TEXT,
            birthDate TEXT,
            phone TEXT,
            department TEXT,
            city TEXT,
            address TEXT,
            neighborhood TEXT,
            email TEXT,
            beneficiaries TEXT,
            eps TEXT,
            arl TEXT,
            arlClass TEXT,
            ccf TEXT,
            pensionFund TEXT,
            ibc REAL,
            description TEXT,
            radicado TEXT,
            solutionDescription TEXT,
            creationDate TEXT,
            updateDate TEXT,
            assignedTo TEXT,
            history TEXT
        );
    """
    )

    try:
        c.execute("SELECT ruta_documento_txt FROM credenciales_plataforma LIMIT 1")
    except sqlite3.OperationalError:
        logger.info(
            "⚠️  Columna 'ruta_documento_txt' no encontrada. Aplicando migración..."
        )
        c.execute(
            "ALTER TABLE credenciales_plataforma ADD COLUMN ruta_documento_txt TEXT;"
        )
        logger.info(
            "✅ Migración aplicada: Columna 'ruta_documento_txt' añadida correctamente."
        )

    conn.commit()
    conn.close()
    logger.info("✅ Base de datos inicializada correctamente.")


initialize_database()

# ==================== REGISTRO DE BLUEPRINTS ====================

# Registrar el Namespace de 'auth' en el objeto 'api' para que aparezca en Swagger
api.add_namespace(auth_ns, path="/api")

# (Los otros blueprints que no hemos modificado se registran como siempre)
app.register_blueprint(bp_empresas, url_prefix="/api")
app.register_blueprint(bp_usuarios, url_prefix="/api")
app.register_blueprint(bp_credenciales, url_prefix="/api")
app.register_blueprint(bp_cotizaciones, url_prefix="/api")
app.register_blueprint(bp_incapacidades, url_prefix="/api")
app.register_blueprint(bp_tutelas, url_prefix="/api")
app.register_blueprint(bp_formularios, url_prefix="/api")
app.register_blueprint(bp_pagos, url_prefix="/api")
app.register_blueprint(bp_impuestos, url_prefix="/api")
app.register_blueprint(bp_envio_planillas, url_prefix="/api")
app.register_blueprint(bp_depuraciones, url_prefix="/api")
app.register_blueprint(bp_novedades, url_prefix="/api")

# ==================== RUTAS PRINCIPALES ====================


@app.route("/")
def serve_root():  # Renombrado de 'root' a 'serve_root' para evitar conflicto
    """Redirige a la página de login"""
    return redirect("/ingresoportal.html")


@app.route("/<path:filename>.html")
def serve_html(filename):
    """
    Sirve archivos HTML del sistema
    """
    file_path = os.path.join(BASE_DIR, f"{filename}.html")

    if filename in ["ingresoportal", "registropotal"]:
        if os.path.exists(file_path):
            return send_from_directory(BASE_DIR, f"{filename}.html")
        else:
            logger.error(f"❌ Archivo HTML de autenticación no encontrado: {file_path}")
            return jsonify({"error": "Página de autenticación no encontrada"}), 404

    if "user_id" not in session:
        logger.warning(f"⚠️  Intento de acceso sin sesión a: {filename}.html")
        return redirect("/ingresoportal.html")

    if os.path.exists(file_path):
        return send_from_directory(BASE_DIR, f"{filename}.html")
    else:
        logger.error(f"❌ Archivo HTML no encontrado: {file_path}")
        return jsonify({"error": "Página no encontrada"}), 404


# ==================== RUTA PARA SERVIR ASSETS ====================
@app.route("/assets/<path:relative_path>")
def serve_assets(relative_path):
    """
    Sirve archivos estáticos desde la carpeta assets/
    """
    safe_path = os.path.normpath(os.path.join(ASSETS_DIR, relative_path))

    try:
        common = os.path.commonpath([safe_path, ASSETS_DIR])
        if common != os.path.normpath(ASSETS_DIR):
            raise ValueError("Intento de acceso fuera del directorio de assets")
    except ValueError:
        logger.warning(f"🚨 Intento de directory traversal detectado: {relative_path}")
        return jsonify({"error": "Acceso denegado"}), 403

    if os.path.exists(safe_path) and os.path.isfile(safe_path):
        directory = os.path.dirname(safe_path)
        filename = os.path.basename(safe_path)

        try:
            return send_from_directory(directory, filename)
        except Exception as e:
            logger.error(f"❌ Error sirviendo asset [{relative_path}]: {e}")
            return jsonify({"error": "Error al servir archivo estático"}), 500
    else:
        logger.warning(f"⚠️  Asset no encontrado: {relative_path}")
        logger.debug(f"   Ruta completa intentada: {safe_path}")
        return jsonify({"error": "Archivo no encontrado"}), 404


# ==================== RUTA PARA UPLOADS ====================
@app.route("/uploads/<path:filename>")
@login_required
def serve_uploaded_file(filename):
    """
    Sirve archivos subidos por usuarios (requiere autenticación)
    """
    upload_folder_abs = app.config.get("UPLOAD_FOLDER", UPLOAD_FOLDER)

    if not os.path.isabs(upload_folder_abs):
        upload_folder_abs = os.path.join(BASE_DIR, upload_folder_abs)

    safe_path = os.path.normpath(os.path.join(upload_folder_abs, filename))

    try:
        common = os.path.commonpath([safe_path, upload_folder_abs])
        if common != os.path.normpath(upload_folder_abs):
            raise ValueError("Intento de acceso fuera del directorio de uploads")
    except ValueError:
        logger.warning(f"🚨 Intento de directory traversal en uploads: {filename}")
        return jsonify({"error": "Acceso denegado"}), 403

    if os.path.exists(safe_path) and os.path.isfile(safe_path):
        directory = os.path.dirname(safe_path)
        base_filename = os.path.basename(safe_path)
        return send_from_directory(directory, base_filename)
    else:
        logger.warning(f"⚠️  Upload no encontrado: {filename}")
        return jsonify({"error": "Archivo no encontrado"}), 404


# ==================== MANEJO DE ERRORES ====================


@app.errorhandler(404)
def not_found(error):
    """Maneja errores 404 - Recurso no encontrado"""
    if request.path.startswith("/api/"):
        return jsonify({"error": "Recurso API no encontrado"}), 404
    return "Recurso no encontrado", 404


@app.errorhandler(401)
def unauthorized(error):
    """Maneja errores 401 - No autorizado"""
    if request.path.startswith("/api/"):
        return (
            jsonify({"error": "Acceso no autorizado. Se requiere inicio de sesión"}),
            401,
        )
    return redirect("/ingresoportal.html")


@app.errorhandler(500)
def internal_error(error):
    """Maneja errores 500 - Error interno del servidor"""
    logger.error(f"💥 Error interno del servidor: {error}", exc_info=True)

    if request.path.startswith("/api/"):
        return jsonify({"error": "Error interno del servidor"}), 500
    return "Error interno del servidor", 500


@app.errorhandler(413)
def request_entity_too_large(error):
    """Maneja errores 413 - Archivo demasiado grande"""
    max_size = app.config["MAX_CONTENT_LENGTH"] / (1024 * 1024)
    return (
        jsonify(
            {
                "error": f"El archivo es demasiado grande. Tamaño máximo: {max_size:.1f} MB"
            }
        ),
        413,
    )


# ==================== INICIO DEL SERVIDOR ====================
if __name__ == "__main__":
    host = os.getenv("FLASK_HOST", "127.0.0.1")
    port = int(os.getenv("FLASK_PORT", 5000))
    debug = app.config["DEBUG"]

    print("\n" + "=" * 70)
    logger.info(f"🚀 Servidor Flask iniciando en http://{host}:{port}")
    logger.info(f"   Modo Debug: {'✅ Activado' if debug else '⚠️  Desactivado'}")
    logger.info(f"   Entorno: {app.config['ENV']}")
    print("=" * 70 + "\n")

    app.run(host=host, port=port, debug=debug)
