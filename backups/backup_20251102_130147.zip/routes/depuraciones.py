# -*- coding: utf-8 -*-
# Este es el contenido para el NUEVO archivo: routes/depuraciones.py

from flask import Blueprint, request, jsonify, session
from utils import get_db_connection, login_required
import json
import os
from datetime import datetime
import traceback
from logger import get_logger

logger = get_logger(__name__)

# Definir el Blueprint
bp_depuraciones = Blueprint("bp_depuraciones", __name__, url_prefix="/api/depuraciones")


@bp_depuraciones.route("/pendientes", methods=["GET"])
@login_required
def get_depuraciones_pendientes():
    """Obtiene todos los registros marcados como pendientes de depuración."""
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute(
            "SELECT id, entidad_nombre, causa, fecha_sugerida FROM depuraciones_pendientes WHERE estado = 'Pendiente' ORDER BY fecha_sugerida"
        )
        pendientes = [dict(row) for row in c.fetchall()]
        return jsonify(pendientes), 200
    except Exception as e:
        logger.error("Error en operación", exc_info=True)
        return jsonify({"error": f"Error al consultar depuraciones: {str(e)}"}), 500
    finally:
        conn.close()


@bp_depuraciones.route("/iniciar", methods=["POST"])
@login_required
def iniciar_proceso_depuracion():
    """
    Inicia la búsqueda de registros para depurar.
    Simula la lógica del frontend: busca usuarios con +1 año de antigüedad.
    """
    conn = get_db_connection()
    c = conn.cursor()
    nuevos_pendientes_count = 0

    try:
        # 1. Buscar usuarios con más de 365 días de antigüedad (usando julianday)
        # julianday('now') - julianday(fechaIngreso) > 365
        c.execute(
            """
            SELECT numeroId, primerNombre, primerApellido, fechaIngreso 
            FROM usuarios 
            WHERE julianday('now') - julianday(fechaIngreso) > 365
        """
        )
        usuarios_antiguos = c.fetchall()

        fecha_sugerida = datetime.now().strftime("%Y-%m-%d")
        causa = "Inactividad (+1 año)"

        for user in usuarios_antiguos:
            # 2. Verificar que no esté YA en la lista de pendientes
            c.execute(
                "SELECT id FROM depuraciones_pendientes WHERE entidad_id = ? AND estado = 'Pendiente'",
                (user["numeroId"],),
            )
            if c.fetchone() is None:
                # 3. Si no está, insertarlo en la tabla de pendientes
                entidad_nombre = f"Empleado: {user['primerNombre']} {user['primerApellido']} (CC {user['numeroId']})"
                c.execute(
                    """
                    INSERT INTO depuraciones_pendientes (entidad_tipo, entidad_id, entidad_nombre, causa, estado, fecha_sugerida) 
                    VALUES (?, ?, ?, ?, ?, ?)
                """,
                    (
                        "usuario",
                        user["numeroId"],
                        entidad_nombre,
                        causa,
                        "Pendiente",
                        fecha_sugerida,
                    ),
                )

                nuevos_pendientes_count += 1

        conn.commit()
        return (
            jsonify(
                {
                    "message": f"Se encontraron {nuevos_pendientes_count} nuevo(s) registro(s) para depurar.",
                    "nuevos_pendientes": nuevos_pendientes_count,
                }
            ),
            200,
        )

    except Exception as e:
        conn.rollback()
        logger.error("Error en operación", exc_info=True)
        return jsonify({"error": f"Error al iniciar depuración: {str(e)}"}), 500
    finally:
        conn.close()


@bp_depuraciones.route("/<int:depuracion_id>/resolver", methods=["PUT"])
@login_required
def resolver_depuracion(depuracion_id):
    """
    Resuelve un item pendiente.
    'aprobar' = ELIMINA EL REGISTRO ORIGINAL.
    'rechazar' = Mantiene el registro original, pero lo quita de pendientes.
    """
    data = request.json
    accion = data.get("accion")  # 'aprobar' o 'rechazar'

    if not accion:
        return jsonify({"error": "Falta la 'accion' (aprobar/rechazar)"}), 400

    conn = get_db_connection()
    c = conn.cursor()

    try:
        # 1. Obtener el item pendiente
        c.execute(
            "SELECT * FROM depuraciones_pendientes WHERE id = ? AND estado = 'Pendiente'",
            (depuracion_id,),
        )
        item = c.fetchone()

        if not item:
            return (
                jsonify({"error": "Registro pendiente no encontrado o ya resuelto"}),
                404,
            )

        message = ""

        if accion == "aprobar":
            # Â¡ACCIÓN DESTRUCTIVA!
            if item["entidad_tipo"] == "usuario":
                # Eliminar el registro de la tabla 'usuarios'
                c.execute(
                    "DELETE FROM usuarios WHERE numeroId = ?", (item["entidad_id"],)
                )
                # Marcar como 'Aprobada' la depuración
                c.execute(
                    "UPDATE depuraciones_pendientes SET estado = 'Aprobada' WHERE id = ?",
                    (depuracion_id,),
                )
                message = f"Depuración Aprobada: El registro {item['entidad_nombre']} ha sido eliminado."

            # (Aquí podrías añadir lógica para 'empresa' si existiera)

        elif accion == "rechazar":
            # Acción segura: solo actualiza el estado
            c.execute(
                "UPDATE depuraciones_pendientes SET estado = 'Rechazada' WHERE id = ?",
                (depuracion_id,),
            )
            message = f"Depuración Rechazada: El registro {item['entidad_nombre']} se conservará."

        else:
            return jsonify({"error": "Acción no válida"}), 400

        conn.commit()
        return jsonify({"success": True, "message": message}), 200

    except Exception as e:
        conn.rollback()
        logger.error("Error en operación", exc_info=True)
        return jsonify({"error": f"Error al resolver depuración: {str(e)}"}), 500
    finally:
        conn.close()
